import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.signal import butter, filtfilt, windows
from scipy.fft import fft, fftfreq
from scipy.stats import ttest_ind

# --- Función para leer la señal desde Excel ---
def read_signal_from_excel(file_path):
    df = pd.read_excel(file_path)
    time = df.iloc[:, 0].values
    data = df.iloc[:, 1].values
    return time, data

# --- Función para aplicar filtros pasa altas y pasa bajas ---
def butter_filter(data, lowcut, highcut, fs, order=5):
    nyquist = 0.5 * fs
    low = lowcut / nyquist
    high = highcut / nyquist
    b, a = butter(order, [low, high], btype='band')
    return filtfilt(b, a, data)

# --- Función para dividir la señal en ventanas y aplicar una ventana de Hamming ---
def apply_windowing(filtered_data, sampling_rate):
    window_size = int(0.5 * sampling_rate)  # Definir tamaño de la ventana en base al tiempo (0.5 segundos aquí)
    window = windows.hamming(window_size)   # Ventana de Hamming
    num_windows = len(filtered_data) // window_size  # Número de ventanas completas en la señal
    windowed_data = []
    
    for i in range(num_windows):
        segment = filtered_data[i*window_size:(i+1)*window_size]  # Extraer segmentos de la señal filtrada
        windowed_segment = segment * window  # Aplicar la ventana
        windowed_data.append(windowed_segment)

    return np.array(windowed_data), window_size

# --- Función para calcular la frecuencia dominante, media y desviación estándar --- 
def calculate_frequency_parameters(spectrum, freqs):
    # Frecuencia dominante
    dominant_freq_index = np.argmax(spectrum)
    dominant_frequency = freqs[dominant_freq_index]

    # Frecuencia media
    total_power = np.sum(spectrum)
    weighted_freq_sum = np.sum(freqs * spectrum)
    mean_frequency = weighted_freq_sum / total_power if total_power > 0 else 0

    # Desviación estándar
    std_dev_frequency = np.std(spectrum)

    return {
        'dominant_frequency': dominant_frequency,
        'mean_frequency': mean_frequency,
        'std_dev_frequency': std_dev_frequency
    }

# --- Función para realizar el análisis espectral ---
def spectral_analysis(windowed_data, sampling_rate, window_size):
    spectral_data = [np.abs(fft(w))[:window_size // 2] for w in windowed_data]
    freqs = fftfreq(window_size, 1/sampling_rate)[:window_size // 2]
    return spectral_data, freqs

# --- Cálculo de la frecuencia mediana por ventana ---
def calculate_median_frequency(spectral_data, freqs):
    median_frequencies = []
    for spectrum in spectral_data:
        cumsum = np.cumsum(spectrum)
        median_idx = np.where(cumsum >= cumsum[-1] / 2)[0][0]  # Índice de la frecuencia mediana
        median_frequencies.append(freqs[median_idx])  # Agregar la frecuencia mediana
    return median_frequencies

# --- Cálculo de la mediana por ventana ---
def calculate_median_per_window(windowed_data):
    medians = [np.median(window) for window in windowed_data]  # Calcula la mediana de cada ventana
    return medians

# --- Función para realizar la prueba de hipótesis ---
def hypothesis_test(median_frequencies):
    mid_point = len(median_frequencies) // 2
    first_half = median_frequencies[:mid_point]
    second_half = median_frequencies[mid_point:]
    
    # Realizar prueba de hipótesis t-test para comparar la primera mitad y la segunda mitad
    stat, p_value = ttest_ind(first_half, second_half)
    
    if p_value < 0.05:
        print("Existe una diferencia significativa en la frecuencia mediana, indicando fatiga muscular.")
    else:
        print("No se observó una diferencia significativa en la frecuencia mediana.")
    
    return p_value

# --- Menú Principal ---
def main_menu():
    file_path = 'emg_signal_with_fatigue.xlsx'
    sampling_rate = 1000  # Hz

    while True:
        print("\n--- Menú de Laboratorio EMG ---")
        print("1. Leer señal desde Excel y mostrar características")
        print("2. Filtrar señal EMG y mostrar parámetros del filtro")
        print("3. Aplicar ventana y mostrar su efecto")
        print("4. Transformada de Fourier y análisis de frecuencias")
        print("5. Prueba de Hipótesis para Fatiga Muscular")
        print("6. Salir")

        choice = input("Selecciona una opción: ")

        if choice == "1":
            print("Leyendo señal desde archivo Excel...")
            time, data = read_signal_from_excel(file_path)

            # Mostrar detalles de la señal
            duration = len(time) / sampling_rate
            print(f"Frecuencia de muestreo: {sampling_rate} Hz")
            print(f"Duración de la señal: {duration:.2f} segundos")
            print(f"Longitud de la señal: {len(data)} puntos")
            print(f"Contracciones: {10} contracciones")
            plt.figure(figsize=(10, 4))
            plt.plot(time, data, color='purple')
            plt.title('Señal EMG Cruda desde Excel')
            plt.xlabel('Tiempo [s]')
            plt.ylabel('Voltaje [mV]')
            plt.grid(True)
            plt.show()

        elif choice == "2":
            print("Aplicando filtros pasa altas y pasa bajas...")
            _, data = read_signal_from_excel(file_path)
            lowcut = 20.0
            highcut = 450.0
            order = 5
            d2 = data[1:100]
            filtered_data = butter_filter(d2, lowcut, highcut, sampling_rate, order)

            # Mostrar detalles del filtro
            print(f"Filtro pasa banda aplicado con corte de {lowcut}-{highcut} Hz y orden {order}.")

            time = np.linspace(0, len(filtered_data) / sampling_rate, len(filtered_data))
            plt.figure(figsize=(10, 4))
            plt.plot(time, filtered_data, color='blue')
            plt.title('Señal EMG Filtrada (20-450 Hz)')
            plt.xlabel('Tiempo [s]')
            plt.ylabel('Voltaje [mV]')
            plt.grid(True)
            plt.show()

        elif choice == "3":
            print("Aplicando aventanamiento y mostrando el efecto de la ventana...")
            _, data = read_signal_from_excel(file_path)
            filtered_data = butter_filter(data, 20.0, 450.0, sampling_rate)
            windowed_data, window_size = apply_windowing(filtered_data, sampling_rate)
            # Calcular la mediana de cada ventana
            medians = calculate_median_per_window(windowed_data)

            # Mostrar las medianas de las ventanas
            for i, median_value in enumerate(medians):
                print(f"Mediana de la ventana {i+1}: {median_value}")

            # Mostrar la señal antes del aventanamiento
            time = np.linspace(0, len(filtered_data) / sampling_rate, len(filtered_data))
            plt.figure(figsize=(10, 4))
            plt.plot(time, filtered_data, label="Señal Filtrada", color='blue')
            plt.title('Señal Filtrada (antes del aventanamiento)')
            plt.xlabel('Tiempo [s]')
            plt.ylabel('Voltaje [mV]')
            plt.grid(True)
            plt.show()

            # Mostrar las ventanas aplicadas
            for i, windowed_segment in enumerate(windowed_data[:5]):  # Mostramos solo las primeras 5 ventanas
                plt.figure(figsize=(10, 4))
                plt.plot(windowed_segment, label=f"Ventana {i+1}", color='green')
                plt.title(f'Señal Aventanada - Ventana {i+1}')
                plt.xlabel('Muestras')
                plt.ylabel('Voltaje [mV]')
                plt.grid(True)
                plt.show()

        elif choice == "4":
            print("Realizando transformada de Fourier y análisis de frecuencias...")
            _, data = read_signal_from_excel(file_path)
            filtered_data = butter_filter(data, 20.0, 450.0, sampling_rate)
            windowed_data, window_size = apply_windowing(filtered_data, sampling_rate)
            spectral_data, freqs = spectral_analysis(windowed_data, sampling_rate, window_size)

            # Graficar y calcular parámetros para cada ventana
            for i in range(min(5, len(spectral_data))):  # Solo para las primeras 5 ventanas
                plt.figure(figsize=(10, 4))
                plt.plot(freqs, spectral_data[i], color='green')
                plt.title(f'Espectro de Frecuencia - Ventana {i + 1}')
                plt.xlabel('Frecuencia [Hz]')
                plt.ylabel('Amplitud')
                plt.grid(True)
                plt.show()
                
                # Calcular y mostrar parámetros de frecuencia
                frequency_params = calculate_frequency_parameters(spectral_data[i], freqs)
                print(f"Ventana {i + 1}: Frecuencia Dominante: {frequency_params['dominant_frequency']:.2f} Hz, "
                      f"Frecuencia Media: {frequency_params['mean_frequency']:.2f} Hz, "
                      f"Desviación Estándar: {frequency_params['std_dev_frequency']:.2f}")

        elif choice == "5":
            print("Realizando prueba de hipótesis para evaluar la fatiga muscular...")
            _, data = read_signal_from_excel(file_path)
            filtered_data = butter_filter(data, 20.0, 450.0, sampling_rate)
            windowed_data, window_size = apply_windowing(filtered_data, sampling_rate)
            spectral_data, freqs = spectral_analysis(windowed_data, sampling_rate, window_size)

            median_frequencies = calculate_median_frequency(spectral_data, freqs)
            p_value = hypothesis_test(median_frequencies)
            print(f"P-valor de la prueba de hipótesis: {p_value}")

        elif choice == "6":
            print("Saliendo del programa.")
            break

        else:
            print("Opción no válida. Por favor, intenta de nuevo.")

# Ejecutar el menú principal
if __name__ == "__main__":
    main_menu()
